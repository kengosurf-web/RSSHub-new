import { Hono } from 'hono';
import { compress } from 'hono/compress';
import { jsxRenderer } from 'hono/jsx-renderer';
import { trimTrailingSlash } from 'hono/trailing-slash';

import api from '@/api';
import { errorHandler, notFoundHandler } from '@/errors';
import accessControl from '@/middleware/access-control';
import antiHotlink from '@/middleware/anti-hotlink';
import cache from '@/middleware/cache';
import debug from '@/middleware/debug';
import header from '@/middleware/header';
import honeybadger from '@/middleware/honeybadger';
import mLogger from '@/middleware/logger';
import parameter from '@/middleware/parameter';
import sentry from '@/middleware/sentry';
import template from '@/middleware/template';
import trace from '@/middleware/trace';
import registry from '@/registry';
import logger from '@/utils/logger';

process.on('uncaughtException', (e) => {
    logger.error('uncaughtException: ' + e);
});

const app = new Hono();

app.use(trimTrailingSlash());
app.use(compress());

app.use(
    jsxRenderer(({ children }) => <>{children}</>, {
        docType: '<?xml version="1.0" encoding="UTF-8"?>',
        stream: {},
    })
);
app.use(mLogger);
app.use(trace);
app.use(honeybadger);
app.use(sentry);
app.use(accessControl);
app.use(debug);
app.use(template);
app.use(header);
app.use(antiHotlink);
app.use(parameter);
app.use(cache);

app.route('/', registry);
app.route('/api', api);

app.notFound(notFoundHandler);
app.onError(errorHandler);

export default app;
